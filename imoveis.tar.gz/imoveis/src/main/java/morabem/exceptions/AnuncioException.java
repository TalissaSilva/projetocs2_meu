package morabem.exceptions;

public class AnuncioException {

    public static class NaoEmcontrado extends Exception { }
}
