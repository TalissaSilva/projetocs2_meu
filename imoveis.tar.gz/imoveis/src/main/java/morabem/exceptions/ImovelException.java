package morabem.exceptions;

public class ImovelException {

    public static class ImovelNaoExiste extends Exception { }

}
