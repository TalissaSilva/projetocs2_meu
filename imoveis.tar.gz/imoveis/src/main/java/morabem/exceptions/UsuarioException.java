package morabem.exceptions;

public abstract class UsuarioException {

    public static class UsuarioNaoEncontrado extends Exception {  }

}
