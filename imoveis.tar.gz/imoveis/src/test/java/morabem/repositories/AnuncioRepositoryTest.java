
package morabem.repositories;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import builders.AnuncioBuilder;
import builders.AnuncioBuilder.Anuncio;
import morabem.domain.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;


@RunWith(SpringRunner.class)
@DataJpaTest
public class AnuncioRepositoryTest {

	@Autowired
	public TestEntityManager testEntityManager;

	@Autowired
	public AnuncioRepository anuncioRepository;


	@Test
	public void salvarAnuncio() {
		morabem.domain.Anuncio anuncio;
		anuncio = AnuncioBuilder.Anuncio.obterUm().agora();
		anuncioRepository.save(anuncio);
		anuncioRepository.flush();
	}

	@Test
	public void crud() {
		morabem.domain.Anuncio anuncio;
		anuncio = AnuncioBuilder.Anuncio.obterUm().agora();

		morabem.domain.Anuncio outroanuncio ;
		outroanuncio = anuncioRepository.saveAndFlush(anuncio);

		assertThat(anuncio, is(equalTo(outroanuncio)));
		assertThat(anuncio.getId(), is(notNullValue()));
	}

}

